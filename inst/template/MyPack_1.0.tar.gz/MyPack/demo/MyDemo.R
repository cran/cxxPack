x <- 3
df <- data.frame(a=c('alpha', 'beta', 'beta', 'gamma'), b=c(1,2,4,5))
MyTest(x, df)
